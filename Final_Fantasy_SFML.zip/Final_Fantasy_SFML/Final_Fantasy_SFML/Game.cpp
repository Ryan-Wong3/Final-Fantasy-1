//
// Created by Ryan Wong on 4/16/2022.
//

#include "Game.h"
#include "Player.h"
#include "Menu.h"
#include "Battle.h"

Game::Game(){

    srand(time(NULL));

}

void Game::run() {

    sf::RenderWindow window({1000, 850, 32},"Final Fantasy");
    window.setFramerateLimit(60);

    Animation Warrior(WARRIOR_WORLD, 2, 4, {1000, 800});
    //Warrior.setUserControl({sf::Keyboard::A, sf::Keyboard::W, sf::Keyboard::D, sf::Keyboard::S});
    Warrior.setPosition(500, 400);

    float deltaTime = 0.0f;
    sf::Clock clock;

    //Battle menu set up
    Battle battle({window.getSize().x, window.getSize().y});

    while(window.isOpen())
    {
        deltaTime = clock.restart().asSeconds();

        sf::Event event;

        while(window.pollEvent(event))
        {
            if(event.type == sf::Event::Closed){
                window.close();
            }
            switch(event.type){

                //event when a ey is pressed
                case sf::Event::KeyPressed:

                    //keycode
                    switch(event.key.code){

                        case sf::Keyboard::W:
                            if(!battle.getInBattleOptions()){
                                battle.menu.MoveUp();
                            }
                            else{
                                if(battle.inFight()) {
                                    battle.pointBeforeEnemy();
                                }
                            }

                            //battle.heros[0].takeDamage(5);
                            //battle.move();
                            break;

                        case sf::Keyboard::S:
                            if(!battle.getInBattleOptions()){
                                battle.menu.MoveDown();
                            }
                            else{
                                if(battle.inFight()){
                                    battle.pointNextEnemy();
                                }
                            }

                            break;

                            ///Battle Menu
                        case sf::Keyboard::Return:

                            if(!battle.getInBattleOptions()){
                                switch(battle.menu.GetPressedItem()){

                                    case 0:
                                        //std::cout << "Fight" << std::endl;
                                        battle.fight();
                                        break;
                                    case 1:
                                        std::cout << "MAGIC" << std::endl;

                                        break;
                                    case 2:
                                        std::cout << "ITEM" << std::endl;

                                        break;
                                    case 3:

                                        window.close();
                                        break;
                                }
                            }
                            //if in one of the selected options
                            else{
                                if(battle.inFight()){
                                    battle.setAction(FIGHT);
                                }
                            }

                            break;

                        case sf::Keyboard::BackSpace:
                            //go back to default selection
                            if(battle.getInBattleOptions()){
                                battle.returnBack();
                            }
                    }
            }


        }

        Warrior.eventHandler(window, deltaTime);

        window.clear(sf::Color::Black);

        battle.draw(window);
        window.draw(Warrior);


        window.display();
    }

}




