//
// Created by Ryan Wong on 4/30/2022.
//

#ifndef ANIMATION_H_ACTIONNAMES_H
#define ANIMATION_H_ACTIONNAMES_H

enum ActionNames{

    FIGHT,

    //DIFFERENT MAGICS
    FIRE,
    CURE,

    //ITEMS

    LAST_ACTION
};

#endif //ANIMATION_H_ACTIONNAMES_H
