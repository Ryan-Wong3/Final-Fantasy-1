#include "Game.h"

int main() {

    Game FinalFantasy;
    FinalFantasy.run();
}
