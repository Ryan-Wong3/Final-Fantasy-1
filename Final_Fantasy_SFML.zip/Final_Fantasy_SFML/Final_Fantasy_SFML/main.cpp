#include "Game.h"
#include "SFML/Audio.hpp"

int main() {

    //sf::Music music;
    Game FinalFantasy(sf::Vector2u(1000, 850));
    FinalFantasy.run();
}
