//
// Created by Ryan Wong on 4/16/2022.
//

#ifndef MAIN_CPP_USERCONTROLENUM_H
#define MAIN_CPP_USERCONTROLENUM_H

#include <SFML/Graphics.hpp>

struct UserControlEnum {

    sf::Keyboard::Key left, top, right,down;

};
#endif //MAIN_CPP_USERCONTROLENUM_H
