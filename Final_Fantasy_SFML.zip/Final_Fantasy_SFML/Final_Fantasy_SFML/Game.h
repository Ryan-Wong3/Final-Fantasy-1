//
// Created by Ryan Wong on 4/16/2022.
//

#ifndef MAIN_CPP_GAME_H
#define MAIN_CPP_GAME_H

#include "Animation.h"
#include "AnimationTest.h"

class Game {

private:

public:
    Game();

    void run();

};


#endif //MAIN_CPP_GAME_H
